import UIKit
//https://cocoacasts.com/four-clever-uses-of-swift-extensions

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
}

class ViewController: UIViewController {

}

extension ViewController: UITableViewDataSource {

}

extension ViewController: UITableViewDelegate {

}

//Preserving Initializers

struct Person {
    
    // MARK: - Properties
    
    let first: String
    let last: String
    
}

let john = Person(first: "John", last: "Doe")

extension Person {
    
    // MARK: - Initialization
    
    init(dictionary: [String: String]) {
        self.first = dictionary["first"] ?? "John"
        self.last = dictionary["last"] ?? "Doe"
    }
    
}

//let test = Person(

// public funcions
extension Person {
    
    ...
    
}

//private ones
private extension Person {
    
    ...
    
}
