import UIKit

class ViewController: UIViewController {
    override func viewDidAppear(_ animated: Bool) {
        
        SplitWireFrame.presentSplitModule(fromView: self)
    }
}


