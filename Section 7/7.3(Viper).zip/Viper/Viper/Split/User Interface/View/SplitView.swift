//
//  SplitView.swift
//  Viper
//
//  Created by Jonathan Wilson on 02/24/2019.
//  Copyright © 2019 Packt. All rights reserved.
//

import Foundation
import UIKit

class SplitViewController: UIViewController, SplitViewProtocol {
    var presenter: SplitPresenterProtocol?
    @IBOutlet private weak var tableView: UITableView!
    private var dataProperty: SplitDisplayData?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Remove first responder from textfield
        let tap = UITapGestureRecognizer(target: view, action: #selector(UIView.endEditing(_:)))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    func showSplitDisplayData(data: SplitDisplayData) {
        dataProperty = data
        tableView.reloadData()
    }
    
    @IBAction func totalBillEntered(_ sender: UITextField) {
        presenter?.updateWithTotalBill(text: sender.text)
    }
}

extension SplitViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let data = dataProperty else { return 0 }
        return data.titles.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "splitResultCell", for: indexPath)
        
        cell.textLabel?.text = dataProperty?.titles[indexPath.row]
        
        return cell
    }
}
