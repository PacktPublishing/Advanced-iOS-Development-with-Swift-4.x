//
//  SplitWireFrame.swift
//  Viper
//
//  Created by Jonathan Wilson on 02/24/2019.
//  Copyright © 2019 Packt. All rights reserved.
//

import Foundation
import UIKit

class SplitWireFrame: SplitWireFrameProtocol {

    class func presentSplitModule(fromView: UIViewController) {
        
        // Generating module components
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let view = storyboard.instantiateViewController(withIdentifier: "SplitViewController") as! SplitViewController

        let presenter: SplitPresenterProtocol & SplitInteractorOutputProtocol = SplitPresenter()
        let interactor: SplitInteractorInputProtocol = SplitInteractor()
        let APIDataManager: SplitAPIDataManagerInputProtocol = SplitAPIDataManager()
        let localDataManager: SplitLocalDataManagerInputProtocol = SplitLocalDataManager()
        let wireFrame: SplitWireFrameProtocol = SplitWireFrame()

        // Connecting
        view.presenter = presenter
        presenter.view = view
        presenter.wireFrame = wireFrame
        presenter.interactor = interactor
        interactor.presenter = presenter
        interactor.APIDataManager = APIDataManager
        interactor.localDatamanager = localDataManager
        
        fromView.present(view, animated: true, completion: nil)
    }
}
