//
//  SplitPresenter.swift
//  Viper
//
//  Created by Jonathan Wilson on 02/24/2019.
//  Copyright © 2019 Packt. All rights reserved.
//

import Foundation

class SplitPresenter: SplitPresenterProtocol, SplitInteractorOutputProtocol {
    
    weak var view: SplitViewProtocol?
    var interactor: SplitInteractorInputProtocol?
    var wireFrame: SplitWireFrameProtocol?

    init() {}
    
    func updateWithTotalBill(text: String?) {
        guard let amount = text else { return }
        interactor?.calculateSplitsWith(amount: amount)
    }
    
    func splitsUpdated(results: [String]) {
        let data = SplitDisplayData(titles: results)
        view?.showSplitDisplayData(data: data)
    }
}
