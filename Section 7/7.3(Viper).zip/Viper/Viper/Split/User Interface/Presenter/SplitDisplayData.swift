import Foundation

public struct SplitDisplayData: Equatable {
     let titles: [String]
}
