//
//  SplitProtocols.swift
//  Viper
//
//  Created by Jonathan Wilson on 02/24/2019.
//  Copyright © 2019 Packt. All rights reserved.
//

import Foundation
import UIKit

protocol SplitViewProtocol: class {
    var presenter: SplitPresenterProtocol? { get set }
    /**
    * Add here your methods for communication PRESENTER -> VIEW
    */
    func showSplitDisplayData(data: SplitDisplayData)
}

protocol SplitWireFrameProtocol: class {
    static func presentSplitModule(fromView view: UIViewController)
    /**
    * Add here your methods for communication PRESENTER -> WIREFRAME
    */
}

protocol SplitPresenterProtocol: class {
    var view: SplitViewProtocol? { get set }
    var interactor: SplitInteractorInputProtocol? { get set }
    var wireFrame: SplitWireFrameProtocol? { get set }
    /**
    * Add here your methods for communication VIEW -> PRESENTER
    */
    func updateWithTotalBill(text: String?)
}

protocol SplitInteractorOutputProtocol: class {
    /**
    * Add here your methods for communication INTERACTOR -> PRESENTER
    */
    func splitsUpdated(results: [String])
}

protocol SplitInteractorInputProtocol: class
{
    var presenter: SplitInteractorOutputProtocol? { get set }
    var APIDataManager: SplitAPIDataManagerInputProtocol? { get set }
    var localDatamanager: SplitLocalDataManagerInputProtocol? { get set }
    /**
    * Add here your methods for communication PRESENTER -> INTERACTOR
    */
    func calculateSplitsWith(amount: String)
}

protocol SplitDataManagerInputProtocol: class
{
    /**
    * Add here your methods for communication INTERACTOR -> DATAMANAGER
    */
}

protocol SplitAPIDataManagerInputProtocol: class
{
    /**
    * Add here your methods for communication INTERACTOR -> APIDATAMANAGER
    */
}

protocol SplitLocalDataManagerInputProtocol: class
{
    /**
    * Add here your methods for communication INTERACTOR -> LOCALDATAMANAGER
    */
    func getSplitAmount() -> Double
}
