//
//  SplitInteractor.swift
//  Viper
//
//  Created by Jonathan Wilson on 02/24/2019.
//  Copyright © 2019 Packt. All rights reserved.
//

import Foundation

class SplitInteractor: SplitInteractorInputProtocol {

    weak var presenter: SplitInteractorOutputProtocol?
    var APIDataManager: SplitAPIDataManagerInputProtocol?
    var localDatamanager: SplitLocalDataManagerInputProtocol?

    init() {}
    
    func calculateSplitsWith(amount: String) {
        guard let total = Double(amount),
        let dataManager = localDatamanager else { return }
        
        let splitAmount = dataManager.getSplitAmount()
        let individualAmount = total / splitAmount
        
        var results = [String]()
        for _ in 0 ..< Int(splitAmount) {
            results.append("\(individualAmount)")
        }
        
        presenter?.splitsUpdated(results: results)
    }
}
