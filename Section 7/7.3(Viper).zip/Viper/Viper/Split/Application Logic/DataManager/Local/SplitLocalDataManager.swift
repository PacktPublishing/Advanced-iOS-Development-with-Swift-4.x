//
//  SplitLocalDataManager.swift
//  Viper
//
//  Created by Jonathan Wilson on 02/24/2019.
//  Copyright © 2019 Packt. All rights reserved.
//

import Foundation

class SplitLocalDataManager: SplitLocalDataManagerInputProtocol {
    init() {}
    
    func getSplitAmount() -> Double {
        return 2.0
    }
}
