//
//  SplitPresenterTests.swift
//  Viper
//
//  Created by Jonathan Wilson on 02/24/2019.
//  Copyright © 2019 Packt. All rights reserved.
//

import XCTest

class AddPresenterTest: XCTestCase {

    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }

    class MockInteractor: SplitInteractorInputProtocol {

    }

    class MockWireframe: SplitWireFrameProtocol {

    }

    class MockViewController: SplitViewProtocol {

        func setupInitialState() {

        }
    }
}
