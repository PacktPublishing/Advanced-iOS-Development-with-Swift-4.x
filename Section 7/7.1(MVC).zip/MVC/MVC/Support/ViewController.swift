import UIKit

class ViewController: UIViewController {
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
    
        let vc = SplitViewController.fromStoryBoard()
        present(vc, animated: true, completion: nil)
    }
}


