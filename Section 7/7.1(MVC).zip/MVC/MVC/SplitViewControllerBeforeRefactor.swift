import UIKit

class SplitViewControllerBefore: UIViewController, UITableViewDelegate, UITableViewDataSource, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var resultsTableView: UITableView!
    @IBOutlet weak var splitAmountSelector: UIPickerView!
    var splitResults = [String]()
    var totalBill = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tap = UITapGestureRecognizer(target: self.view, action: #selector(UIView.endEditing(_:)))
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
    }

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 100
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return "\(row)"
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        splitResults.removeAll()
        for _ in 0..<row {
            splitResults.append("\(totalBill / Double(row))")
        }
        saveResultsOnServer()
        resultsTableView.reloadData()
    }
    
    
    @IBAction func totalBillEntered(_ sender: UITextField) {
        totalBill = Double(sender.text ?? "0")!
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return splitResults.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = self.resultsTableView.dequeueReusableCell(withIdentifier: "splitResultCell")!
        
        cell.textLabel?.text = splitResults[indexPath.row]
        
        return cell
    }
    
    func saveResultsOnServer() {
        
    }
}
