class Model {
    func saveResultsOnServer() {
        // Network call, maybe database too
    }
}
