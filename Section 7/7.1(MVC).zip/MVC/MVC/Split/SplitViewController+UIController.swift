extension SplitViewController {
    public class UIController {
        private var splitResults = [String]()
        private var totalBill = 0.0
        private let model: Model
        
        init(model: Model = Model()) {
            self.model = model
        }
        
        func updateTotalBill(amount: String) {
            if let total = Double(amount) {
                totalBill = total
            } else {
                totalBill = 0
            }
        }
        
        // Mark: - Result Methods
        
        func updateResults(_ splitCount: Int) {
            splitResults.removeAll()
            
            let splitAmount = Double(splitCount)
            let individualAmount = totalBill / splitAmount
            
            for _ in 0 ..< splitCount {
                splitResults.append("\(individualAmount)")
            }
            
            model.saveResultsOnServer()
        }
        
        func getResultCount() -> Int {
            return splitResults.count
        }
        
        func getResultAt(row: Int) -> String {
            return splitResults[row]
        }
        
        // Mark: - PickerView Methods
        
        func numberOfRowsInPickerView() -> Int {
            return 100
        }
        
        func titleForRowInPickerView(row: Int) -> String {
            return "$\(row)"
        }
    }
}
