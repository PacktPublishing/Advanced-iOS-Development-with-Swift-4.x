import UIKit

class SplitViewController: UIViewController {
    @IBOutlet private weak var resultsTableView: UITableView!
    @IBOutlet private weak var splitAmountSelector: UIPickerView!
    private let uiController = UIController()
    
    class func fromStoryBoard() -> SplitViewController {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "SplitViewController") as! SplitViewController
        return controller
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Remove first responder from textfield
        let tap = UITapGestureRecognizer(target: view, action: #selector(UIView.endEditing(_:)))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }

    @IBAction private func totalBillEntered(_ sender: UITextField) {
        guard let amount = sender.text else { return }
        uiController.updateTotalBill(amount: amount)
    }
}

extension SplitViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return uiController.getResultCount()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = resultsTableView.dequeueReusableCell(withIdentifier: "splitResultCell")!
        cell.textLabel?.text = uiController.getResultAt(row: indexPath.row)
        return cell
    }
}

extension SplitViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return uiController.numberOfRowsInPickerView()
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return uiController.titleForRowInPickerView(row: row)
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        uiController.updateResults(row)
        resultsTableView.reloadData()
    }
}

