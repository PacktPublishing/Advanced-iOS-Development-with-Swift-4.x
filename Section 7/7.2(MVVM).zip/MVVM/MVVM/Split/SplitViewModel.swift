class SplitViewModel {
    private weak var dataSource: GenericDataSource<String>?
    private let splitAmount = 2.0
    
    init(dataSource: GenericDataSource<String>?) {
        self.dataSource = dataSource
    }
    
    func updateWithTotalBill(amount: String) {
        guard let total = Double(amount) else { return }
        
        dataSource?.data.value.removeAll()
        
        let individualAmount = total / splitAmount
        
        var results = [String]()
        for _ in 0 ..< Int(splitAmount) {
            results.append("\(individualAmount)")
        }
        
        dataSource?.data.value = results
    }
}
