import UIKit

class SplitViewController: UIViewController {
    @IBOutlet private weak var tableView: UITableView!
    private let dataSource = SplitViewControllerDataSource()
    
    private lazy var viewModel: SplitViewModel = {
        let viewModel = SplitViewModel(dataSource: dataSource)
        return viewModel
    }()

    class func fromStoryBoard() -> SplitViewController {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "SplitViewController") as! SplitViewController
        return controller
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Remove first responder from textfield
        let tap = UITapGestureRecognizer(target: view, action: #selector(UIView.endEditing(_:)))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
        
        tableView.dataSource = self.dataSource
        dataSource.data.addAndNotify(observer: self) { [weak self] in
            self?.tableView.reloadData()
        }
    }
    
    @IBAction func totalBillEntered(_ sender: UITextField) {
        guard let amount = sender.text else { return }
        viewModel.updateWithTotalBill(amount: amount)
    }
}
