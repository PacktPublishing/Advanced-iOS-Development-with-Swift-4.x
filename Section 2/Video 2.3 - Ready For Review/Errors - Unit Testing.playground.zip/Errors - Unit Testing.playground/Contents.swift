import Foundation
import XCTest

class ScoreKeeper {
    private var score = 0
    
    func getScore() -> Int {
        return score
    }
    
    func incrementScore() {
        score += 1
    }
    
    func incrementScore(_ completion: @escaping (_ newScore: Int) -> Void) {
        incrementScore()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
            completion(self.score)
        })
    }
}

class ScoreKeeperTests: XCTestCase {
    var keeper: ScoreKeeper!
    
    override func setUp() {
        super.setUp()
        keeper = ScoreKeeper()
    }
    
    func testInitialGetScore() {
        XCTAssert(keeper.getScore() == 0)
    }
    
    func testIncrementScore() {
        keeper.incrementScore()
        XCTAssert(keeper.getScore() == 1)
    }
    
    func testScoreIncrementPerformance() {
        measure {
            keeper.incrementScore()
        }
    }
    
    func testAsyncIncrementScore() {
        let scoreExpectation = expectation(description: "Score returned")
        
        keeper.incrementScore { score in
            scoreExpectation.fulfill()
        }
        
        waitForExpectations(timeout: 1) { error in
            
        }
    }
}

ScoreKeeperTests.defaultTestSuite.run()

