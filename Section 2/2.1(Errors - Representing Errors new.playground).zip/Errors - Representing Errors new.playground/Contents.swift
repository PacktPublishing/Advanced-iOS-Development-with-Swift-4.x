import Foundation

struct ParsingError: Error {
    enum MyError: Error {
        case Minor
        case Bad
        case Terrible
    }
    
    let line: Int
    let column: Int
    let kind: MyError
}

func parse(_ source: String) throws {
    throw ParsingError(line: 2, column: 3, kind: .Bad)
}


enum Result<Value, Error> {
    case success(Value)
    case failure(Error)
}

func fetch(_ request: URLRequest,
           completion: (Result<(URLResponse, Data), Never>) -> Void) {
    
}

let request = URLRequest(url: URL(string: "a")!)
fetch(request) { result in
    switch result {
    case let .success(response, _):
        print("Success: \(response)")
    }
}
