import Foundation

class Fridge {
    enum FridgeError: Error {
        case contentNotPresent
        case contentExpired(name: String)
    }
    
    private var content = [
        "UID01": "Juice"
    ]
    
    private var expriedContent = [
        "UID02": "Apple"
    ]
    
    func getContentNameWith(contentID: String) throws -> String {
        if let name = expriedContent[contentID] {
            throw FridgeError.contentExpired(name: name)
        }
        
        guard let name = content[contentID] else {
            throw FridgeError.contentNotPresent
        }
        return name
    }
}

let fridge = Fridge()
let contentName = try fridge.getContentNameWith(contentID: "UID01")

do {
    let _ = try fridge.getContentNameWith(contentID: "UID02")
} catch {
    print("Unexpected fridge error: \(error)")
}

let forcedContentName = try! fridge.getContentNameWith(contentID: "UID01")


extension String: Error {}

throw "Some Error"

extension String: LocalizedError {
    public var errorDescription: String? { return self }
}
