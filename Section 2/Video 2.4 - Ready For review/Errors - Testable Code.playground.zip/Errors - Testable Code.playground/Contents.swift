import Foundation
import XCTest

protocol Database {
    func getWith(key: String) -> Int
    func incrementWith(key: String)
}

class RealDatabase: Database {
    func getWith(key: String) -> Int {
        return 1
    }
    
    func incrementWith(key: String) {
    }
}

class MockDatabase: Database {
    var value = 1
    
    func getWith(key: String) -> Int {
        return value
    }
    
    func incrementWith(key: String) {
        value += 1
    }
}

class ScoreKeeper {
    private var database: Database
    private let scoreKey = "Score"
    
    init(database: Database = RealDatabase() ) {
        self.database = database
    }
    
    func getScore() -> Int {
        return database.getWith(key: scoreKey)
    }
    
    func incrementScore() {
        database.incrementWith(key: scoreKey)
    }
}

class ScoreKeeperTests: XCTestCase {
    var keeper: ScoreKeeper!
    
    override func setUp() {
        super.setUp()
        let database = MockDatabase()
        database.value = 0
        
        keeper = ScoreKeeper(database: database)
    }
    
    func testInitialGetScore() {
        XCTAssertEqual(keeper.getScore(), 0)
    }
    
    func testIncrementScore() {
        keeper.incrementScore()
        XCTAssertEqual(keeper.getScore(), 1)
    }
    
    func testMultipleIncrementScore() {
        keeper.incrementScore()
        keeper.incrementScore()
        XCTAssertEqual(keeper.getScore(), 2)
    }
}

ScoreKeeperTests.defaultTestSuite.run()
