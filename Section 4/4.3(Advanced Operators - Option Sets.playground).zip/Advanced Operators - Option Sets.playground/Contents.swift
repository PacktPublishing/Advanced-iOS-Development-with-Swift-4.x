struct CarOptions: OptionSet {
    let rawValue: Int
    
    static let soundSystem = CarOptions(rawValue: 1 << 0) //1
    static let sportsSeats = CarOptions(rawValue: 1 << 1) //2
    static let alloys = CarOptions(rawValue: 1 << 2)
}

var stock: CarOptions = [.soundSystem, .sportsSeats]

stock.contains(.soundSystem)
stock.remove(.soundSystem)
stock.contains(.soundSystem)
stock.insert(.soundSystem)
stock.contains(.soundSystem)

print(stock)

extension CarOptions: CustomStringConvertible {
    var description: String {
        let strings = ["SoundSystem", "SportsSeats", "Alloys"]
        var members = [String]()
        for (flag, string) in strings.enumerated() where self.contains(CarOptions(rawValue: 1 << (UInt8(flag)))) {
            members.append(string)
        }
        return members.description
    }
}

print(String(describing: CarOptions.alloys))
