import UIKit
import Foundation

prefix operator √
prefix func √(lhs: Double) -> Double {
    return sqrt(lhs)
}

var root = √2


let precedence = UIImage(named: "precedence.png")
precedencegroup SquareSumOperatorPrecedence {
    lowerThan: MultiplicationPrecedence
    higherThan: AdditionPrecedence
    associativity: left
}

infix operator ◉: SquareSumOperatorPrecedence
func ◉(lhs: Double, rhs: Double) -> Double {
    return lhs * lhs + rhs * rhs
}

var y = (2 ◉ 2) + 2
var z = 2 ◉ (2 * 2)

extension CGPoint {
    static func + (lhs: CGPoint, rhs: CGPoint) -> CGPoint {
        return CGPoint(x: lhs.x + rhs.x, y: lhs.y + rhs.y)
    }
}

var point1 = CGPoint(x: 1.0, y: 1.0)
var result = point1 + point1
