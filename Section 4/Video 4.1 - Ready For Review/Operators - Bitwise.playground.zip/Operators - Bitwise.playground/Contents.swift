
//    128 | 64 | 32 | 16 | 8 | 4 | 2 | 1
let binary: UInt8 = 0b00000011


let initialBits: UInt8 = 0b00001111
let invertedBits = ~initialBits

//  ~   00001111 (15)
//  =   11110000 (240)

let firstSixBits: UInt8 = 0b11111100
let lastSixBits: UInt8  = 0b00111111
let middleFourBits = firstSixBits & lastSixBits

//      11111100 (252)
//  &   00111111 (63)
//  =   00111100 (60)

let someBits: UInt8 = 0b10110010
let moreBits: UInt8 = 0b01011110
let combinedbits = someBits | moreBits

//      10110010 (178)
//  |   01011110 (94)
//  =   11111110 (254)

let firstBits: UInt8 = 0b00010100
let otherBits: UInt8 = 0b00000101
let outputBits = firstBits ^ otherBits

//      00010100 (20)
//  ^   00000101 (5)
//  =   00010001 (17)


// Shifting Right
let example1 = 8 >> 1
let example2 = 8 >> 2
// Shifting Left
let example3 = 8 << 1
let example4 = 8 << 2

//0 = 00000000
//1 = 00000001
//2 = 00000010
//3 = 00000011
//4 = 00000100
//...
//8 = 00001000
//...
//16 = 00010000
//...
//32 = 00100000
//...
//64 = 01000000
//...
//128 = 10000000
//...
//255 = 11111111

let num = 25 << 2  // 00011001 (2 shifts left) = 01100100
let num2 = 30 >> 5 // 00011110 (5 shifts right) = 00000000


let pink: UInt32 = 0xCC6699
let redComponent = (pink & 0xFF0000) >> 16  // redComponent is 0xCC, 204
let greenComponent = (pink & 0x00FF00) >> 8 // greenComponent is 0x66, 102
let blueComponent = pink & 0x0000FF         // blueComponent is 0x99, 153

//   0xCC6699 (110011000110011010011001)
// & 0xFF0000 (111111110000000000000000)
// = 0xCC0000 (110011000000000000000000)

//    0xCC0000 (110011000000000000000000)
// >>       16
// =  0x0000CC (or 0xCC) (000000000000000011001100)
