import Foundation

protocol Request {
    associatedtype Response
    associatedtype Error
    
    var baseURL: URL { get }
    var method: String { get }
    var path: String { get }
    
    func parse(from object: Any) -> Response
}

extension Request {
    func buildURLRequest() -> URLRequest {
        let url = path.isEmpty ? baseURL : baseURL.appendingPathComponent(path)
        
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = method
        return urlRequest
    }
}

class Session {
    func send<R: Request>(_ request: R, completion: @escaping (R.Response, R.Error?) -> Void) {
        let urlRequest = request.buildURLRequest()
        
        URLSession.shared.dataTask(with: urlRequest) {(data, response, error) in
            guard let data = data else { return }
            completion(request.parse(from: data), nil)
        }
        
        //task.resume()
        completion(request.parse(from: ""), nil)
    }
}

class UserGetRequest: Request {
    typealias Response = String
    typealias Error = String
    
    var baseURL = URL(string: "www.google.com")!
    var method = "GET"
    var path = "/user"
    
    func parse(from object: Any) -> String {
        return "test"
    }
}

Session().send(UserGetRequest()) { (response, error) in
}
