func exists<T: Equatable>(item: T, in array: [T]) -> Bool {
    for arrayItem in array {
        if item == arrayItem {
            return true
        }
    }
    return false
}

let array = [1,2]
exists(item: 3, in: array)
