protocol Money {
    associatedtype Currency
    var currency: Currency { get }
    var amount: Float { get }
    
    func sum<M: Money>(with money: M) -> M? where M.Currency == Currency
}

class Euro {}
class Pound {}

class Irish: Money {
    typealias Currency = Euro
    
    var currency = Euro()
    var amount: Float = 10.0
    
    func sum<M>(with money: M) -> M? where M : Money, Irish.Currency == M.Currency {
        return nil
    }
}

protocol Tradable {}

protocol Company {
    associatedtype TradeCurency
    func buy<T: Tradable, M: Money>(product: T, with money: M) -> T? where M.Currency == TradeCurency
}

class BerkshireHathaway: Company {
    typealias TradeCurency = Irish
    
    func buy<T, M>(product: T, with money: M) -> T? where T : Tradable, M : Money, BerkshireHathaway.TradeCurency == M.Currency {
        return nil
    }
}

class Oil: Tradable {}
var berk = BerkshireHathaway()
let oil = berk.buy(product: Oil(), with: Irish())

