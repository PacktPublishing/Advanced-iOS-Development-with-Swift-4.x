protocol GenericProtocol {
    associatedtype MyType
    var property: MyType { get set }
}

class StringImplementation: GenericProtocol {
    typealias MyType = String
    var property: MyType = "a"
}

class IntImplementation: GenericProtocol {
    typealias MyType = Int
    var property: MyType = 1
}

var string = StringImplementation()
print(string.property)

var int = IntImplementation()
print(int.property)


