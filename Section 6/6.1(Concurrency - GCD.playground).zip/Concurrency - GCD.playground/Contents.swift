import Foundation
import PlaygroundSupport
PlaygroundPage.current.needsIndefiniteExecution = true

let serialAsyncQueue = DispatchQueue(label: "com.queue.Serial")
for i in 1...5 {
    serialAsyncQueue.async {
        if Thread.isMainThread {
            print("task running in main thread")
        }else{
            print("task running in background thread")
        }
        let imgURL = URL(string: "https://en.wikipedia.org/wiki/File:Packt_Logo.png")!
        let _ = try! Data(contentsOf: imgURL)
        print("\(i) completed downloading")
    }
}

let serialSyncQueue = DispatchQueue(label: "com.queue.Serial")
for i in 1...5 {
    serialSyncQueue.sync {
        if Thread.isMainThread{
            print("task running in main thread")
        }else{
            print("task running in background thread")
        }
        let imgURL = URL(string: "https://en.wikipedia.org/wiki/File:Packt_Logo.png")!
        let _ = try! Data(contentsOf: imgURL)
        print("\(i) completed downloading")
    }
}


let concurrentAsyncQueue = DispatchQueue(label: "com.queue.Concurrent", attributes: .concurrent)
for i in 1...5 {
    concurrentAsyncQueue.async {
        if Thread.isMainThread{
            print("task running in main thread")
        }else{
            print("task running in background thread")
        }
        let imgURL = URL(string: "https://en.wikipedia.org/wiki/File:Packt_Logo.png")!
        let _ = try! Data(contentsOf: imgURL)
        print("\(i) completed downloading")
    }
    print("\(i) executing")
}


let concurrentSyncQueue = DispatchQueue(label: "com.queue.Concurrent", attributes: .concurrent)
for i in 1...5 {
    concurrentSyncQueue.sync {
        if Thread.isMainThread{
            print("task running in main thread")
        }else{
            print("task running in background thread")
        }
        let imgURL = URL(string: "https://en.wikipedia.org/wiki/File:Packt_Logo.png")!
        let _ = try! Data(contentsOf: imgURL)
        print("\(i) completed downloading")
    }
    print("\(i) executed")
}
