import Dispatch

func syncMethod() -> String {
    let semaphore = DispatchSemaphore(value: 0)
    let queue = DispatchQueue.global()
    
    var response: String?
    queue.async {
        sleep(2)
        response = "Done"
        print("Signal")
        semaphore.signal()
    }
    print("Wait")
    semaphore.wait()
    
    guard let result = response else {
        print("Failed")
        return "Failed"
    }
    return result
}

let response = syncMethod()
print(response)


class LockedNumbers {
    let semaphore = DispatchSemaphore(value: 1)
    var elements: [Int] = []
    
    func append(_ num: Int) {
        self.semaphore.wait()
        print("appended: \(num)")
        self.elements.append(num)
        self.semaphore.signal()
    }
    
    func removeLast() {
        self.semaphore.wait()
        defer {
            self.semaphore.signal()
        }
        guard !self.elements.isEmpty else {
            return
        }
        let num = self.elements.removeLast()
        print("removed: \(num)")
    }
}

let items = LockedNumbers()
items.append(1)
items.append(2)
items.append(3)
items.append(4)
items.removeLast()
items.removeLast()
items.append(5)
print(items.elements)
