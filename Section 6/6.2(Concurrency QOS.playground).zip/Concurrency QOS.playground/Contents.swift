import Dispatch

DispatchQueue.main

DispatchQueue.global(qos: .userInteractive)
DispatchQueue.global(qos: .userInitiated)
DispatchQueue.global(qos: .default)
DispatchQueue.global(qos: .utility)
DispatchQueue.global(qos: .background)


DispatchQueue(label: "com.packt.serial")
DispatchQueue(label: "com.packt.concurrent", attributes: .concurrent)





DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1)) {
    print("Complete")
}

DispatchQueue.concurrentPerform(iterations: 5) { (i) in
    print(i)
}





func load(delay: UInt32, completion: () -> Void) {
    sleep(delay)
    completion()
}

let group = DispatchGroup()

group.enter()
load(delay: 1) {
    print("1")
    group.leave()
}

group.enter()
load(delay: 2) {
    print("2")
    group.leave()
}

group.enter()
load(delay: 3) {
    print("3")
    group.leave()
}

group.notify(queue: .main) {
    print("done")
}
