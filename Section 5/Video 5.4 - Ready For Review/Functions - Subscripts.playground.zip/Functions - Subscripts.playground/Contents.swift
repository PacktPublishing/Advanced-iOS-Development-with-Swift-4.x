var response = Dictionary<String, Any>()
response["a"] = "hi"
response["b"] = 2

let a = response["b"] as? Int
print(type(of: a))

// New Dictionary Type that uses subscripts

struct GenericDictionary<Key: Hashable, Value> {
    private var data: [Key: Value]
    
    init(data: [Key: Value]) {
        self.data = data
    }
    
    subscript<T>(key: Key) -> T? {
        return data[key] as? T
    }
}

var genericDictionary = GenericDictionary(data: ["name": "Earth", "pop": 10])

let name: String? = genericDictionary["name"]
let pop: Int? = genericDictionary["pop"]



