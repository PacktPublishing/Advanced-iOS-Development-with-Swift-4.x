struct LargeStruct {
    var myInt = 1
    
    mutating func increaseMyInt() {
        myInt += 1
    }
}

// Incrementing LargeStructs `myInt` without inout

func increment(largeStruct: LargeStruct) -> LargeStruct {
    var copy = largeStruct
    copy.increaseMyInt()
    return copy
}

var structA = LargeStruct(myInt: 1)
var structB = increment(largeStruct: structA)
print(structA)
print(structB)


// Incrementing LargeStructs `myInt` with inout

func withLessOverheadIncrement(largeStruct: inout LargeStruct) {
    largeStruct.increaseMyInt()
}

var structC = LargeStruct(myInt: 1)
withLessOverheadIncrement(largeStruct: &structC)
print(structC)
