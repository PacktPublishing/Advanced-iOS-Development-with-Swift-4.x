var closure: () -> () =  { () -> Void in
    print("Nothing returned")
}
closure()

var closureWithArg: (_ name: String) -> String = {  name in
    return name
}
closureWithArg("Johny")


func repeatSome(word: String) -> () -> String {
    var result = word
    
    func concatenate() -> String {
        result += "\(word)"
        return result
    }
    
    return concatenate
}

var annoying = repeatSome(word: " hey!")

print(annoying())
print(annoying())
print(annoying())



class APIExample {
    var closure: (() -> ())? = nil
    let result = ""
    
    init() {
        print("init")
        // Use '[weak self]' in and 'guard let strongSelf = self else { return }'
        closure = {
            print(self.result)
        }
    }
    
    deinit {
        print("deinit")
    }
}

var api: APIExample? = APIExample()
api = nil

//apiExample -> closure
//apiExample <- closure


