import Foundation

print("a", "b", "c")
let string = String(format: "Hello %@", "Johny")

// Sum function with normal array
func sum1(numbers: [Int]) -> Int {
    var total = 0
    
    for number in numbers {
        total += number
    }
    
    return total
}

// Variadic example
func sum2(_ numbers: Int...) -> Int {
    var total = 0
    
    for number in numbers {
        total += number
    }
    
    return total
}

// Updated with reduce
func sum3(_ numbers: Int...) -> Int {
    return numbers.reduce(0, +)
}
